import java.util.ArrayList;

public class Aluno {
    String nome;
    int matricula;
    int turma;
    ArrayList<Materia> materias = new ArrayList<>();

    Aluno(String nome, int matricula, int turma, ArrayList<Materia> materias){
        this.nome = nome;
        this.matricula = matricula;
        this.turma = turma;
        this.materias = materias;
    }
}