public class Menu {
    Menu(){
        
        double[] notas1 = {10,7,10,3};
        double[] notas2 = {10,7,10,3};
        Materia materia1 = new Materia("matematica", "adriano",notas1);
        Materia materia2 = new Materia("historia", "ze carlos", notas2);


        Materia[] materias = new Materia[materia1, materia2]

        System.out.println(materia1.nomeProfessor);
    }
}