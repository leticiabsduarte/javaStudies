public class Materia {
    public String nome;
    public String nomeProfessor;
    public double[] notas = new double[4];
    
    public Materia(String nome, String nomeProfessor, double[] notas){
        this.nome = nome;
        this.nomeProfessor = nomeProfessor;
        this.notas = notas;
    }

    public String getNome(){
        return this.nome;
    }

    public String getNomeProfessor(){
        return this.nomeProfessor;
    }

}